﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;
using System.Data;

namespace Reagente5000OVERPOWER.Code.DAL
{
    class ClasseDAL
    {
        
        private MySqlConnection conexao = null;
        private DataTable data;
        private MySqlDataAdapter da;
        private MySqlCommandBuilder cb;

        //String de conexão de banco
        string conectaBanco = "SERVER=localhost; DATABASE=controle de reagentes; UID=root; PWD=;";

        public void Conectar()
        { //regra para fechar conexão caso esteja aberta (usado só por precaução)
            if (conexao != null)
                conexao.Close();

            string conectaBanco = "SERVER=localhost; DATABASE=controle de reagentes; UID=root; PWD=;";

            try
            {
                conexao = new MySqlConnection(conectaBanco);
                conexao.Open();
            }
            catch (MySqlException ex)
            {
                throw new Exception(ex.Message);
            }
        }
        

        public DataTable ExibirDados(string sql)
        { //Acessa os dados para carregar no dataGRID
            try
            {
                data = new DataTable();
                da = new MySqlDataAdapter(sql, conectaBanco);
                cb = new MySqlCommandBuilder(da);
                da.Fill(data);

                return data;
            }
            catch(Exception erro)
            {
                throw erro;
            }
            finally
            {
                conexao.Close();
            }

        }
        
        public void ExecutarComandoSQL(string comandoSql)
        {//Desenvolvido um MySqlCommand para executar cada elemento do CRUD 
            MySqlCommand comando = new MySqlCommand(comandoSql, conexao);
            comando.ExecuteNonQuery();
            conexao.Close();
        }
        

    }
}
