﻿namespace Reagente5000OVERPOWER
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.reagentesBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.controle_de_reagentesDataSet = new Reagente5000OVERPOWER.controle_de_reagentesDataSet();
            this.reagentesTableAdapter = new Reagente5000OVERPOWER.controle_de_reagentesDataSetTableAdapters.reagentesTableAdapter();
            this.btnSave = new System.Windows.Forms.Button();
            this.btnAdd = new System.Windows.Forms.Button();
            this.btnDel = new System.Windows.Forms.Button();
            this.btnAlt = new System.Windows.Forms.Button();
            this.txtName = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.checkInerte = new System.Windows.Forms.CheckBox();
            this.txtMarca = new System.Windows.Forms.TextBox();
            this.txtQuantidade = new System.Windows.Forms.TextBox();
            this.txtMedida = new System.Windows.Forms.TextBox();
            this.dateEntrada = new System.Windows.Forms.DateTimePicker();
            this.dataValidade = new System.Windows.Forms.DateTimePicker();
            this.btnExibir = new System.Windows.Forms.Button();
            this.textID = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.reagentesBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.controle_de_reagentesDataSet1 = new Reagente5000OVERPOWER.controle_de_reagentesDataSet1();
            this.reagentesTableAdapter1 = new Reagente5000OVERPOWER.controle_de_reagentesDataSet1TableAdapters.reagentesTableAdapter();
            this.dataSaida = new System.Windows.Forms.MaskedTextBox();
            this.reagentesBindingSource2 = new System.Windows.Forms.BindingSource(this.components);
            this.controle_de_reagentesDataSet2 = new Reagente5000OVERPOWER.controle_de_reagentesDataSet2();
            this.reagentesTableAdapter2 = new Reagente5000OVERPOWER.controle_de_reagentesDataSet2TableAdapters.reagentesTableAdapter();
            this.btProcurar = new System.Windows.Forms.Button();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.Inerte = new System.Windows.Forms.Label();
            this.qtdeminima = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.reagentesBindingSource3 = new System.Windows.Forms.BindingSource(this.components);
            this.controle_de_reagentesDataSet3 = new Reagente5000OVERPOWER.controle_de_reagentesDataSet3();
            this.reagentesTableAdapter3 = new Reagente5000OVERPOWER.controle_de_reagentesDataSet3TableAdapters.reagentesTableAdapter();
            this.label18 = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.reagentesBindingSource4 = new System.Windows.Forms.BindingSource(this.components);
            this.controle_de_reagentesDataSet4 = new Reagente5000OVERPOWER.controle_de_reagentesDataSet4();
            this.reagentesTableAdapter4 = new Reagente5000OVERPOWER.controle_de_reagentesDataSet4TableAdapters.reagentesTableAdapter();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.iDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.idreagenteDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nomeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.marcaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dtentradaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dtvalidadeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.quantidadeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.qtdeminimaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.medidaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.inerteDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dtsaidaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.reagentesBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.controle_de_reagentesDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.reagentesBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.controle_de_reagentesDataSet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.reagentesBindingSource2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.controle_de_reagentesDataSet2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.reagentesBindingSource3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.controle_de_reagentesDataSet3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.reagentesBindingSource4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.controle_de_reagentesDataSet4)).BeginInit();
            this.SuspendLayout();
            // 
            // reagentesBindingSource
            // 
            this.reagentesBindingSource.DataMember = "reagentes";
            this.reagentesBindingSource.DataSource = this.controle_de_reagentesDataSet;
            // 
            // controle_de_reagentesDataSet
            // 
            this.controle_de_reagentesDataSet.DataSetName = "controle_de_reagentesDataSet";
            this.controle_de_reagentesDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // reagentesTableAdapter
            // 
            this.reagentesTableAdapter.ClearBeforeFill = true;
            // 
            // btnSave
            // 
            this.btnSave.Location = new System.Drawing.Point(781, 15);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(75, 23);
            this.btnSave.TabIndex = 1;
            this.btnSave.Text = "Adicionar";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnAdd
            // 
            this.btnAdd.Location = new System.Drawing.Point(781, 110);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(75, 23);
            this.btnAdd.TabIndex = 2;
            this.btnAdd.Text = "Novo";
            this.btnAdd.UseVisualStyleBackColor = true;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // btnDel
            // 
            this.btnDel.Location = new System.Drawing.Point(781, 77);
            this.btnDel.Name = "btnDel";
            this.btnDel.Size = new System.Drawing.Size(75, 23);
            this.btnDel.TabIndex = 3;
            this.btnDel.Text = "Excluir";
            this.btnDel.UseVisualStyleBackColor = true;
            this.btnDel.Click += new System.EventHandler(this.btnDel_Click);
            // 
            // btnAlt
            // 
            this.btnAlt.Location = new System.Drawing.Point(781, 47);
            this.btnAlt.Name = "btnAlt";
            this.btnAlt.Size = new System.Drawing.Size(75, 23);
            this.btnAlt.TabIndex = 4;
            this.btnAlt.Text = "Alterar";
            this.btnAlt.UseVisualStyleBackColor = true;
            this.btnAlt.Click += new System.EventHandler(this.btnAlt_Click);
            // 
            // txtName
            // 
            this.txtName.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtName.Location = new System.Drawing.Point(184, 12);
            this.txtName.Name = "txtName";
            this.txtName.Size = new System.Drawing.Size(317, 20);
            this.txtName.TabIndex = 5;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(143, 15);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(35, 13);
            this.label1.TabIndex = 6;
            this.label1.Text = "Nome";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(9, 47);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(37, 13);
            this.label2.TabIndex = 7;
            this.label2.Text = "Marca";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(9, 77);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(70, 13);
            this.label3.TabIndex = 8;
            this.label3.Text = "Data Entrada";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(194, 77);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(48, 13);
            this.label4.TabIndex = 9;
            this.label4.Text = "Validade";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(9, 145);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(62, 13);
            this.label5.TabIndex = 10;
            this.label5.Text = "Quantidade";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(9, 181);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(28, 13);
            this.label6.TabIndex = 11;
            this.label6.Text = "Lote";
            // 
            // checkInerte
            // 
            this.checkInerte.AutoSize = true;
            this.checkInerte.Location = new System.Drawing.Point(409, 46);
            this.checkInerte.Name = "checkInerte";
            this.checkInerte.Size = new System.Drawing.Size(64, 17);
            this.checkInerte.TabIndex = 13;
            this.checkInerte.Text = "Inativo?";
            this.checkInerte.UseVisualStyleBackColor = true;
            // 
            // txtMarca
            // 
            this.txtMarca.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtMarca.Location = new System.Drawing.Point(56, 44);
            this.txtMarca.Name = "txtMarca";
            this.txtMarca.Size = new System.Drawing.Size(317, 20);
            this.txtMarca.TabIndex = 14;
            // 
            // txtQuantidade
            // 
            this.txtQuantidade.Location = new System.Drawing.Point(85, 142);
            this.txtQuantidade.Name = "txtQuantidade";
            this.txtQuantidade.Size = new System.Drawing.Size(66, 20);
            this.txtQuantidade.TabIndex = 16;
            this.txtQuantidade.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtQuantidade_KeyPress);
            // 
            // txtMedida
            // 
            this.txtMedida.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtMedida.Location = new System.Drawing.Point(85, 178);
            this.txtMedida.MaxLength = 10;
            this.txtMedida.Name = "txtMedida";
            this.txtMedida.Size = new System.Drawing.Size(66, 20);
            this.txtMedida.TabIndex = 18;
            // 
            // dateEntrada
            // 
            this.dateEntrada.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateEntrada.Location = new System.Drawing.Point(85, 71);
            this.dateEntrada.Name = "dateEntrada";
            this.dateEntrada.Size = new System.Drawing.Size(83, 20);
            this.dateEntrada.TabIndex = 19;
            // 
            // dataValidade
            // 
            this.dataValidade.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dataValidade.Location = new System.Drawing.Point(248, 71);
            this.dataValidade.Name = "dataValidade";
            this.dataValidade.Size = new System.Drawing.Size(81, 20);
            this.dataValidade.TabIndex = 20;
            // 
            // btnExibir
            // 
            this.btnExibir.Location = new System.Drawing.Point(781, 145);
            this.btnExibir.Name = "btnExibir";
            this.btnExibir.Size = new System.Drawing.Size(75, 23);
            this.btnExibir.TabIndex = 21;
            this.btnExibir.Text = "Exibir";
            this.btnExibir.UseVisualStyleBackColor = true;
            this.btnExibir.Click += new System.EventHandler(this.btnExibir_Click);
            // 
            // textID
            // 
            this.textID.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.textID.Location = new System.Drawing.Point(56, 12);
            this.textID.Name = "textID";
            this.textID.Size = new System.Drawing.Size(81, 20);
            this.textID.TabIndex = 22;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(10, 15);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(40, 13);
            this.label7.TabIndex = 23;
            this.label7.Text = "Código";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(9, 110);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(60, 13);
            this.label8.TabIndex = 24;
            this.label8.Text = "Data Saida";
            // 
            // reagentesBindingSource1
            // 
            this.reagentesBindingSource1.DataMember = "reagentes";
            this.reagentesBindingSource1.DataSource = this.controle_de_reagentesDataSet1;
            // 
            // controle_de_reagentesDataSet1
            // 
            this.controle_de_reagentesDataSet1.DataSetName = "controle_de_reagentesDataSet1";
            this.controle_de_reagentesDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // reagentesTableAdapter1
            // 
            this.reagentesTableAdapter1.ClearBeforeFill = true;
            // 
            // dataSaida
            // 
            this.dataSaida.Location = new System.Drawing.Point(85, 107);
            this.dataSaida.Mask = "00/00/0000";
            this.dataSaida.Name = "dataSaida";
            this.dataSaida.Size = new System.Drawing.Size(83, 20);
            this.dataSaida.TabIndex = 27;
            this.dataSaida.ValidatingType = typeof(System.DateTime);
            this.dataSaida.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.dataSaida_KeyPress);
            // 
            // reagentesBindingSource2
            // 
            this.reagentesBindingSource2.DataMember = "reagentes";
            this.reagentesBindingSource2.DataSource = this.controle_de_reagentesDataSet2;
            // 
            // controle_de_reagentesDataSet2
            // 
            this.controle_de_reagentesDataSet2.DataSetName = "controle_de_reagentesDataSet2";
            this.controle_de_reagentesDataSet2.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // reagentesTableAdapter2
            // 
            this.reagentesTableAdapter2.ClearBeforeFill = true;
            // 
            // btProcurar
            // 
            this.btProcurar.Location = new System.Drawing.Point(528, 10);
            this.btProcurar.Name = "btProcurar";
            this.btProcurar.Size = new System.Drawing.Size(75, 23);
            this.btProcurar.TabIndex = 29;
            this.btProcurar.Text = "Procurar";
            this.btProcurar.UseVisualStyleBackColor = true;
            this.btProcurar.Click += new System.EventHandler(this.btProcurar_Click);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(82, 217);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(40, 13);
            this.label9.TabIndex = 30;
            this.label9.Text = "Código";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(143, 217);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(35, 13);
            this.label10.TabIndex = 31;
            this.label10.Text = "Nome";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(321, 217);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(37, 13);
            this.label11.TabIndex = 32;
            this.label11.Text = "Marca";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(422, 217);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(70, 13);
            this.label12.TabIndex = 33;
            this.label12.Text = "Data Entrada";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(796, 217);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(60, 13);
            this.label13.TabIndex = 34;
            this.label13.Text = "Data Saida";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(507, 217);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(48, 13);
            this.label14.TabIndex = 35;
            this.label14.Text = "Validade";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(561, 217);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(62, 13);
            this.label15.TabIndex = 36;
            this.label15.Text = "Quantidade";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(711, 217);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(28, 13);
            this.label16.TabIndex = 37;
            this.label16.Text = "Lote";
            // 
            // Inerte
            // 
            this.Inerte.AutoSize = true;
            this.Inerte.Location = new System.Drawing.Point(756, 217);
            this.Inerte.Name = "Inerte";
            this.Inerte.Size = new System.Drawing.Size(39, 13);
            this.Inerte.TabIndex = 38;
            this.Inerte.Text = "Inativo";
            // 
            // qtdeminima
            // 
            this.qtdeminima.Location = new System.Drawing.Point(285, 142);
            this.qtdeminima.Name = "qtdeminima";
            this.qtdeminima.Size = new System.Drawing.Size(73, 20);
            this.qtdeminima.TabIndex = 39;
            this.qtdeminima.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.qtdeminima_KeyPress);
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(181, 145);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(98, 13);
            this.label17.TabIndex = 40;
            this.label17.Text = "Quantidade Minima";
            // 
            // reagentesBindingSource3
            // 
            this.reagentesBindingSource3.DataMember = "reagentes";
            this.reagentesBindingSource3.DataSource = this.controle_de_reagentesDataSet3;
            // 
            // controle_de_reagentesDataSet3
            // 
            this.controle_de_reagentesDataSet3.DataSetName = "controle_de_reagentesDataSet3";
            this.controle_de_reagentesDataSet3.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // reagentesTableAdapter3
            // 
            this.reagentesTableAdapter3.ClearBeforeFill = true;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(639, 217);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(66, 13);
            this.label18.TabIndex = 42;
            this.label18.Text = "Qtde Minima";
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.ColumnHeadersVisible = false;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.iDDataGridViewTextBoxColumn,
            this.idreagenteDataGridViewTextBoxColumn,
            this.nomeDataGridViewTextBoxColumn,
            this.marcaDataGridViewTextBoxColumn,
            this.dtentradaDataGridViewTextBoxColumn,
            this.dtvalidadeDataGridViewTextBoxColumn,
            this.quantidadeDataGridViewTextBoxColumn,
            this.qtdeminimaDataGridViewTextBoxColumn,
            this.medidaDataGridViewTextBoxColumn,
            this.inerteDataGridViewTextBoxColumn,
            this.dtsaidaDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.reagentesBindingSource4;
            this.dataGridView1.Location = new System.Drawing.Point(13, 237);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(865, 201);
            this.dataGridView1.TabIndex = 43;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick_1);
            // 
            // reagentesBindingSource4
            // 
            this.reagentesBindingSource4.DataMember = "reagentes";
            this.reagentesBindingSource4.DataSource = this.controle_de_reagentesDataSet4;
            // 
            // controle_de_reagentesDataSet4
            // 
            this.controle_de_reagentesDataSet4.DataSetName = "controle_de_reagentesDataSet4";
            this.controle_de_reagentesDataSet4.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // reagentesTableAdapter4
            // 
            this.reagentesTableAdapter4.ClearBeforeFill = true;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(663, 8);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(46, 20);
            this.textBox1.TabIndex = 44;
            this.textBox1.Visible = false;
            // 
            // iDDataGridViewTextBoxColumn
            // 
            this.iDDataGridViewTextBoxColumn.DataPropertyName = "ID";
            this.iDDataGridViewTextBoxColumn.HeaderText = "ID";
            this.iDDataGridViewTextBoxColumn.Name = "iDDataGridViewTextBoxColumn";
            this.iDDataGridViewTextBoxColumn.Width = 20;
            // 
            // idreagenteDataGridViewTextBoxColumn
            // 
            this.idreagenteDataGridViewTextBoxColumn.DataPropertyName = "idreagente";
            this.idreagenteDataGridViewTextBoxColumn.HeaderText = "idreagente";
            this.idreagenteDataGridViewTextBoxColumn.Name = "idreagenteDataGridViewTextBoxColumn";
            this.idreagenteDataGridViewTextBoxColumn.Width = 70;
            // 
            // nomeDataGridViewTextBoxColumn
            // 
            this.nomeDataGridViewTextBoxColumn.DataPropertyName = "nome";
            this.nomeDataGridViewTextBoxColumn.HeaderText = "nome";
            this.nomeDataGridViewTextBoxColumn.Name = "nomeDataGridViewTextBoxColumn";
            this.nomeDataGridViewTextBoxColumn.Width = 170;
            // 
            // marcaDataGridViewTextBoxColumn
            // 
            this.marcaDataGridViewTextBoxColumn.DataPropertyName = "marca";
            this.marcaDataGridViewTextBoxColumn.HeaderText = "marca";
            this.marcaDataGridViewTextBoxColumn.Name = "marcaDataGridViewTextBoxColumn";
            this.marcaDataGridViewTextBoxColumn.Width = 110;
            // 
            // dtentradaDataGridViewTextBoxColumn
            // 
            this.dtentradaDataGridViewTextBoxColumn.DataPropertyName = "dtentrada";
            this.dtentradaDataGridViewTextBoxColumn.HeaderText = "dtentrada";
            this.dtentradaDataGridViewTextBoxColumn.Name = "dtentradaDataGridViewTextBoxColumn";
            this.dtentradaDataGridViewTextBoxColumn.Width = 70;
            // 
            // dtvalidadeDataGridViewTextBoxColumn
            // 
            this.dtvalidadeDataGridViewTextBoxColumn.DataPropertyName = "dtvalidade";
            this.dtvalidadeDataGridViewTextBoxColumn.HeaderText = "dtvalidade";
            this.dtvalidadeDataGridViewTextBoxColumn.Name = "dtvalidadeDataGridViewTextBoxColumn";
            this.dtvalidadeDataGridViewTextBoxColumn.Width = 70;
            // 
            // quantidadeDataGridViewTextBoxColumn
            // 
            this.quantidadeDataGridViewTextBoxColumn.DataPropertyName = "quantidade";
            this.quantidadeDataGridViewTextBoxColumn.HeaderText = "quantidade";
            this.quantidadeDataGridViewTextBoxColumn.Name = "quantidadeDataGridViewTextBoxColumn";
            this.quantidadeDataGridViewTextBoxColumn.Width = 70;
            // 
            // qtdeminimaDataGridViewTextBoxColumn
            // 
            this.qtdeminimaDataGridViewTextBoxColumn.DataPropertyName = "qtdeminima";
            this.qtdeminimaDataGridViewTextBoxColumn.HeaderText = "qtdeminima";
            this.qtdeminimaDataGridViewTextBoxColumn.Name = "qtdeminimaDataGridViewTextBoxColumn";
            this.qtdeminimaDataGridViewTextBoxColumn.Width = 70;
            // 
            // medidaDataGridViewTextBoxColumn
            // 
            this.medidaDataGridViewTextBoxColumn.DataPropertyName = "medida";
            this.medidaDataGridViewTextBoxColumn.HeaderText = "medida";
            this.medidaDataGridViewTextBoxColumn.Name = "medidaDataGridViewTextBoxColumn";
            this.medidaDataGridViewTextBoxColumn.Width = 50;
            // 
            // inerteDataGridViewTextBoxColumn
            // 
            this.inerteDataGridViewTextBoxColumn.DataPropertyName = "inerte";
            this.inerteDataGridViewTextBoxColumn.HeaderText = "inerte";
            this.inerteDataGridViewTextBoxColumn.Name = "inerteDataGridViewTextBoxColumn";
            this.inerteDataGridViewTextBoxColumn.Width = 40;
            // 
            // dtsaidaDataGridViewTextBoxColumn
            // 
            this.dtsaidaDataGridViewTextBoxColumn.DataPropertyName = "dtsaida";
            this.dtsaidaDataGridViewTextBoxColumn.HeaderText = "dtsaida";
            this.dtsaidaDataGridViewTextBoxColumn.Name = "dtsaidaDataGridViewTextBoxColumn";
            this.dtsaidaDataGridViewTextBoxColumn.Width = 90;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(890, 450);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.qtdeminima);
            this.Controls.Add(this.Inerte);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.btProcurar);
            this.Controls.Add(this.dataSaida);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.textID);
            this.Controls.Add(this.btnExibir);
            this.Controls.Add(this.dataValidade);
            this.Controls.Add(this.dateEntrada);
            this.Controls.Add(this.txtMedida);
            this.Controls.Add(this.txtQuantidade);
            this.Controls.Add(this.txtMarca);
            this.Controls.Add(this.checkInerte);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtName);
            this.Controls.Add(this.btnAlt);
            this.Controls.Add(this.btnDel);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.btnSave);
            this.Name = "Form1";
            this.Text = "Controle de Reagentes";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.reagentesBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.controle_de_reagentesDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.reagentesBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.controle_de_reagentesDataSet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.reagentesBindingSource2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.controle_de_reagentesDataSet2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.reagentesBindingSource3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.controle_de_reagentesDataSet3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.reagentesBindingSource4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.controle_de_reagentesDataSet4)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private controle_de_reagentesDataSet controle_de_reagentesDataSet;
        private System.Windows.Forms.BindingSource reagentesBindingSource;
        private controle_de_reagentesDataSetTableAdapters.reagentesTableAdapter reagentesTableAdapter;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.Button btnDel;
        private System.Windows.Forms.Button btnAlt;
        private System.Windows.Forms.TextBox txtName;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.CheckBox checkInerte;
        private System.Windows.Forms.TextBox txtMarca;
        private System.Windows.Forms.TextBox txtQuantidade;
        private System.Windows.Forms.TextBox txtMedida;
        private System.Windows.Forms.DateTimePicker dateEntrada;
        private System.Windows.Forms.DateTimePicker dataValidade;
        private System.Windows.Forms.Button btnExibir;
        private System.Windows.Forms.TextBox textID;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private controle_de_reagentesDataSet1 controle_de_reagentesDataSet1;
        private System.Windows.Forms.BindingSource reagentesBindingSource1;
        private controle_de_reagentesDataSet1TableAdapters.reagentesTableAdapter reagentesTableAdapter1;
        private System.Windows.Forms.MaskedTextBox dataSaida;
        private controle_de_reagentesDataSet2 controle_de_reagentesDataSet2;
        private System.Windows.Forms.BindingSource reagentesBindingSource2;
        private controle_de_reagentesDataSet2TableAdapters.reagentesTableAdapter reagentesTableAdapter2;
        private System.Windows.Forms.Button btProcurar;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label Inerte;
        private System.Windows.Forms.TextBox qtdeminima;
        private System.Windows.Forms.Label label17;
        private controle_de_reagentesDataSet3 controle_de_reagentesDataSet3;
        private System.Windows.Forms.BindingSource reagentesBindingSource3;
        private controle_de_reagentesDataSet3TableAdapters.reagentesTableAdapter reagentesTableAdapter3;
        private System.Windows.Forms.Label label18;
        private controle_de_reagentesDataSet4 controle_de_reagentesDataSet4;
        private System.Windows.Forms.BindingSource reagentesBindingSource4;
        private controle_de_reagentesDataSet4TableAdapters.reagentesTableAdapter reagentesTableAdapter4;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.DataGridViewTextBoxColumn iDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn idreagenteDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn nomeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn marcaDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn dtentradaDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn dtvalidadeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn quantidadeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn qtdeminimaDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn medidaDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn inerteDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn dtsaidaDataGridViewTextBoxColumn;
    }
}

