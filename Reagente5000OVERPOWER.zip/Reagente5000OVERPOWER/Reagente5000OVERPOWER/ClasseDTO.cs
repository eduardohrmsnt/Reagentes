﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Reagente5000OVERPOWER.Code.DTO
{
    class ClasseDTO
    { //Feito a classe DTO para declarar os Getters e Setters
        
        string nome, marca, medida, dataSaida,idreagente;
        double quantidade;
        DateTime dataValidade, dataEntrada;
        string inerte;

        public string ID
        {
            get { return idreagente; }
            set { idreagente = value; }
        }
        
        public string Nome
        {
            get { return nome; }
            set { nome = value; }
        }

        public string Marca
        {
            get { return marca; }
            set { marca = value; }
        }

        public string Medida
        {
            get { return medida; }
            set { medida = value; }
        }

        public Double Quantidade
        {
            get { return quantidade; }
            set { quantidade = value; }
        }


        public string Inerte
        {
            get { return inerte; }
            set { inerte = value; }
        }

        public DateTime DataValidade
        {
            get { return dataValidade; }
            set { dataValidade = value; }
        }

        public DateTime DataEntrada
        {
            get { return dataEntrada; }
            set { dataEntrada = value; }
        }

        public string DataSaida
        {
            get { return dataSaida; }
            set { dataSaida = value; }
        }
           
    }
}
