﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Reagente5000OVERPOWER.Code.BLL;
using Reagente5000OVERPOWER.Code.DTO;

namespace Reagente5000OVERPOWER
{
    public partial class Form1 : Form
    {
        ClasseBLL bll = new ClasseBLL();
        ClasseDTO dto = new ClasseDTO();
        
            
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: esta linha de código carrega dados na tabela 'controle_de_reagentesDataSet2.reagentes'. Você pode movê-la ou removê-la conforme necessário.
            this.reagentesTableAdapter2.Fill(this.controle_de_reagentesDataSet2.reagentes);
            CarregarGrid();
            RowsColor();


        }

        private void btnExibir_Click(object sender, EventArgs e)
        {
            //Atualiza dados na tela
            try
            {
                dataGridView1.DataSource = bll.ExibirDadosDal();
            }
            catch(Exception erro)
            {
                MessageBox.Show("Erro ao Exibir os Dados! " + erro);
            }
            CarregarGrid();
            RowsColor();


        }

        private void btnSave_Click(object sender, EventArgs e)
        {   //Transfere o valor dos campos para o dto que será usando na BLL para fazer o insert
            //Regra implementada para que o usuário preencha todos os campos
            if (textID.Text!="" & txtName.Text != "" & txtMarca.Text != "" & txtQuantidade.Text != "" & txtMedida.Text != "")
            {
                try
                {
                    dto.ID = textID.Text;
                    dto.Nome = txtName.Text;
                    dto.Marca = txtMarca.Text;
                    dto.Medida = txtMedida.Text;
                    dto.Quantidade = Convert.ToDouble(txtQuantidade.Text);
                    dto.DataEntrada = Convert.ToDateTime(dateEntrada.Text);
                    dto.DataValidade = Convert.ToDateTime(dataValidade.Text);
                    dto.DataSaida = Convert.ToString(dataSaida.Text);
                    dto.Inerte = Convert.ToString(checkInerte.Checked);
                    bll.Salvar(dto);
                    CarregarGrid();
                    RowsColor();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
            else
            {
                MessageBox.Show("Preencha todos os campos!");
            }
        }

        private void CarregarGrid()
        {//Feito para que quando abrir o form já exiba o dataGrid
            dataGridView1.DataSource = bll.ExibirDadosDal();

        }

        public void RowsColor()
        { //implementado a RNF da mudança de cor caso esteja proximo da validade
            //Usado o for looping para checar linha por linha.
            //Colocado o dataGridView1.Rows.Count - 1 para que não ficasse vermelha a ultima linha (nova ROW)
            for (int i=0; i < dataGridView1.Rows.Count - 1; i++)
            {
                DateTime val;
                DateTime val2;
                

                val = DateTime.Now;
                val2 = Convert.ToDateTime(dataGridView1.Rows[i].Cells[4].Value);
                

                if (val2 <= val)
                {
                    dataGridView1.Rows[i].DefaultCellStyle.BackColor = Color.Red;
                }
                if (val2 <= val.AddDays(10) & val2 > val)
                {
                    dataGridView1.Rows[i].DefaultCellStyle.BackColor = Color.Orange;
                }
            }
        }

        

        private void btnAdd_Click(object sender, EventArgs e)
        { //Limpa os dados para novo cadastro
            textID.Text = "";
            txtName.Text = "";
            txtMarca.Text = "";
            dateEntrada.Text = "";
            dataValidade.Text = "";
            txtQuantidade.Text = "";
            txtMedida.Text = "";
            checkInerte.Checked = false;
            dataSaida.Text = "";
            CarregarGrid();
            RowsColor();
        }

        private void btnDel_Click(object sender, EventArgs e)
        { //Pega ID para usar no DTO da BLL Deletar
            //Criado regra para usuario selecionar o registro.
            if (textID.Text != "")
            {
                dto.ID = textID.Text;
                bll.Deletar(dto);
                CarregarGrid();
                RowsColor();
            }
            else
            { MessageBox.Show("Escolha um registro!"); }
        }

        private void btnAlt_Click(object sender, EventArgs e)
        {
            //Criado regra para usuario selecionar o registro.
            if (textID.Text != "") {
                //Transfere o valor dos campos para o dto que será usando na BLL para fazer o update
                dto.ID = textID.Text;
                dto.Nome = txtName.Text;
                dto.Marca = txtMarca.Text;
                dto.Medida = txtMedida.Text;
                dto.Quantidade = Convert.ToDouble(txtQuantidade.Text);
                dto.DataEntrada = Convert.ToDateTime(dateEntrada.Text);
                dto.DataValidade = Convert.ToDateTime(dataValidade.Text);
                dto.DataSaida = Convert.ToString(dataSaida.Text);
                dto.Inerte = Convert.ToString(checkInerte.Checked);
            } 
            else
            { MessageBox.Show("Escolha um registro!"); }
            bll.Atualizar(dto);
            CarregarGrid();
            RowsColor();
        }

        private void txtQuantidade_KeyPress(object sender, KeyPressEventArgs e)
        {//Implementado para que no TextBox txtQuantidade só possa digitar números.

            if (!(char.IsDigit(e.KeyChar) || char.IsControl(e.KeyChar)))

                {

                    e.Handled = true;
                MessageBox.Show("Digite apenas números!");

                }
            
        }

        private void dataSaida_KeyPress(object sender, KeyPressEventArgs e)
        {//Implementado para que no TextBox dataSaida só possa digitar números.
            if (!(char.IsDigit(e.KeyChar) || char.IsControl(e.KeyChar)))

            {

                e.Handled = true;
                MessageBox.Show("Digite apenas números!");

            }
        }

        private void btProcurar_Click(object sender, EventArgs e)
        {
            //Pega ID para procura
            //Criado regra para usuario digitar o registro
            if (textID.Text != "")
            {
                dto.ID = textID.Text;
                dataGridView1.DataSource = bll.Pesquisar(dto);
                RowsColor();
            }
            else
            { MessageBox.Show("Digite o codigo do reagente!"); }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            //Carrega os dados para os devidos campos
            textID.Text = dataGridView1.Rows[e.RowIndex].Cells[0].Value.ToString();
            txtName.Text = dataGridView1.Rows[e.RowIndex].Cells[1].Value.ToString();
            txtMarca.Text = dataGridView1.Rows[e.RowIndex].Cells[2].Value.ToString();
            dateEntrada.Text = dataGridView1.Rows[e.RowIndex].Cells[3].Value.ToString();
            dataValidade.Text = dataGridView1.Rows[e.RowIndex].Cells[4].Value.ToString();
            txtQuantidade.Text = dataGridView1.Rows[e.RowIndex].Cells[5].Value.ToString();
            txtMedida.Text = dataGridView1.Rows[e.RowIndex].Cells[6].Value.ToString();
            checkInerte.Checked = Convert.ToBoolean(dataGridView1.Rows[e.RowIndex].Cells[7].Value.ToString());
            dataSaida.Text = dataGridView1.Rows[e.RowIndex].Cells[8].Value.ToString();

        }
    }
}
