﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using Reagente5000OVERPOWER.Code.DTO;
using Reagente5000OVERPOWER.Code.DAL;

namespace Reagente5000OVERPOWER.Code.BLL
{
    class ClasseBLL
    {
        ClasseDAL dal;
        //Na DAL foi implementada uma função para que abra e feche a conexão em cada um dos elementos do CRUD

        public DataTable ExibirDadosDal()
        {//BLL para Exibir Dados usando atributos da DAL
            DataTable DataT = new DataTable();
            try
            {

                dal = new ClasseDAL();
                dal.Conectar();

                DataT = dal.ExibirDados("SELECT idreagente,nome,marca,dtentrada,dtvalidade,quantidade,medida,inerte,dtsaida FROM reagentes");



            }
            catch (Exception erro)
            {
                throw new Exception("Erro ao selecionar os reagentes" + erro);
            }

            return DataT;
        }

        public void Salvar(ClasseDTO dto)
        {//BLL para Salvar usando atributos da DAL
            try
            {

                string nome = dto.Nome.Replace("'", "''");
                dal = new ClasseDAL();
                dal.Conectar();
                string comando1 = "INSERT INTO reagentes(idreagente,nome,marca,dtentrada,dtvalidade,quantidade,medida,inerte,dtsaida) VALUES('" + dto.ID + "','" + nome + "','" + dto.Marca + "','" + dto.DataEntrada + "','" + dto.DataValidade + "','" + dto.Quantidade + "','" + dto.Medida + "','" + dto.Inerte + "','" + dto.DataSaida + "')";
                dal.ExecutarComandoSQL(comando1);
            }
            catch (Exception ex)
            {
                throw new Exception("Reagente já existente!");
            }

        }

        public void Deletar(ClasseDTO dto)
        {//BLL para Deletar usando atributos da DAL
            try
            {


                dal = new ClasseDAL();
                dal.Conectar();
                string comando1 = "DELETE FROM reagentes WHERE idreagente ='" + dto.ID + "';";
                dal.ExecutarComandoSQL(comando1);
            }
            catch (Exception ex)
            {
                throw new Exception("Erro ao tentar deletar o cliente" + ex.Message);
            }

        }

        public void Atualizar(ClasseDTO dto)
        {
            try
            {


                dal = new ClasseDAL();
                dal.Conectar();
                string comando1 = "UPDATE reagentes SET idreagente='" + dto.ID + " nome='" + dto.Nome + "', marca='" + dto.Marca + "', dtentrada='" + dto.DataEntrada + "', dtvalidade='" + dto.DataValidade + "', quantidade=" + dto.Quantidade + ", medida='" + dto.Medida + "', inerte='" + dto.Inerte + "', dtsaida='" + dto.DataSaida + "' WHERE idreagente =" + dto.ID + ";";
                dal.ExecutarComandoSQL(comando1);
            }
            catch (Exception ex)
            {
                throw new Exception("Erro ao tentar atualizar o cliente" + ex.Message);
            }
        }
        public DataTable Pesquisar(ClasseDTO dto)
        {//BLL para Exibir Dados usando atributos da DAL
            DataTable DataT = new DataTable();
            try
            {

                dal = new ClasseDAL();
                dal.Conectar();
                DataT = dal.ExibirDados ("SELECT idreagente,nome,marca,dtentrada,dtvalidade,quantidade,medida,inerte,dtsaida FROM reagentes where idreagente like '" + dto.ID + "%';");
                
                


            }
            catch (Exception erro)
            {
                throw new Exception("Erro ao pesquisar Reagentes!" + erro);
            }

            return DataT;

        }
    }
}
